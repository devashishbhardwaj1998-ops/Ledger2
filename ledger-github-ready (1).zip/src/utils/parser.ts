import * as XLSX from 'xlsx';
import { RawEmployeeRow, RawEmployerRow, WeekInfo, RegionInfo, RegionType, DEFAULT_REGION_COUNTRY_CODES } from '../types';

export const TYPE_MAP: Record<string, { axis: 'production' | 'review'; category: string }> = {
  'full':                   { axis: 'production', category: 'Full' },
  'limited':                { axis: 'production', category: 'Limited' },
  'minimal':                { axis: 'production', category: 'Minimal' },
  'semicurated':            { axis: 'production', category: 'Semi' },
  'updatedfull':            { axis: 'production', category: 'Update (full)' },
  'updatedlimited':         { axis: 'production', category: 'Update (limited)' },
  'conversionlimitedtofull':{ axis: 'production', category: 'Update (LtF)' },
  'partialnews':            { axis: 'production', category: 'In the news' },
  'firstreview':            { axis: 'review', category: 'Full first' },
  'finalreviewfull':        { axis: 'review', category: 'Full final' },
  'finalreviewlimited':     { axis: 'review', category: 'Limited final' },
  'finalreviewsemicurated': { axis: 'review', category: 'Semi final' },
  'updatedreviewfull':      { axis: 'review', category: 'Update R (full)' },
  'updatedreviewlimited':   { axis: 'review', category: 'Update R (limited)' },
  'partialnewsreview':      { axis: 'review', category: 'Mini-update' }
};

export const TRACKED_TYPES = new Set([
  'updatedreviewfull',
  'updatedreviewlimited',
  'updatedfull',
  'updatedlimited',
  'updatereviewfull',
  'updatereviewlimited',
  'updatefull',
  'updatelimited',
  'updaterfull',
  'updaterlimited',
  'updatedrfull',
  'updatedrlimited'
]);

export const TRACKED_CATEGORIES = new Set([
  'Update (full)',
  'Update (limited)',
  'Update R (full)',
  'Update R (limited)'
]);

export function normalizeTrackedCategory(val: unknown): string | null {
  if (!val) return null;
  const s = String(val)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');

  if (!s) return null;

  // Full production
  if (
    s === 'updatefull' ||
    s === 'updatedfull' ||
    s === 'fullupdate' ||
    s === 'updatefullasset'
  ) {
    return 'Update (full)';
  }

  // Limited production
  if (
    s === 'updatelimited' ||
    s === 'updatedlimited' ||
    s === 'limitedupdate' ||
    s === 'updatelimitedasset'
  ) {
    return 'Update (limited)';
  }

  // Full review
  if (
    s === 'updaterfull' ||
    s === 'updatedrfull' ||
    s === 'updatedreviewfull' ||
    s === 'updatereviewfull' ||
    s === 'reviewfull' ||
    s === 'reviewfullupdate'
  ) {
    return 'Update R (full)';
  }

  // Limited review
  if (
    s === 'updaterlimited' ||
    s === 'updatedrlimited' ||
    s === 'updatedreviewlimited' ||
    s === 'updatereviewlimited' ||
    s === 'reviewlimited' ||
    s === 'reviewlimitedupdate'
  ) {
    return 'Update R (limited)';
  }

  return null;
}

export function resolveProductionCategory(productionVal: unknown): string | null {
  const s = String(productionVal || '').trim();
  if (!s || s === '-' || s === '—' || s === 'n/a' || s === 'none' || s === '0') return null;

  const cat = normalizeTrackedCategory(s);
  if (cat === 'Update (full)' || cat === 'Update (limited)') return cat;

  const clean = s.toLowerCase().replace(/[^a-z0-9]/g, '');
  if (clean.includes('upd') || clean.startsWith('u') || clean.includes('update')) {
    if (clean.includes('lim')) return 'Update (limited)';
    if (clean.includes('full')) return 'Update (full)';
  }
  return null;
}

export function resolveReviewCategory(reviewVal: unknown): string | null {
  const s = String(reviewVal || '').trim();
  if (!s || s === '-' || s === '—' || s === 'n/a' || s === 'none' || s === '0') return null;

  const cat = normalizeTrackedCategory(s);
  if (cat === 'Update R (full)' || cat === 'Update R (limited)') return cat;
  if (cat === 'Update (full)') return 'Update R (full)';
  if (cat === 'Update (limited)') return 'Update R (limited)';

  const clean = s.toLowerCase().replace(/[^a-z0-9]/g, '');
  if (clean.includes('upd') || clean.startsWith('u') || clean.includes('rev') || clean.includes('r')) {
    if (clean.includes('lim')) return 'Update R (limited)';
    if (clean.includes('full')) return 'Update R (full)';
  }
  return null;
}

export function resolveEmployerCategory(
  productionVal: unknown,
  reviewVal: unknown
): string | null {
  // Review category check first
  const revCat = resolveReviewCategory(reviewVal);
  if (revCat) return revCat;

  // Production category check
  const prodCat = resolveProductionCategory(productionVal);
  if (prodCat) return prodCat;

  return null;
}

export function normAsset(s: unknown): string {
  return String(s || '')
    .trim()
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

const MONTH_NAME_MAP: Record<string, string> = {
  jan: '01',
  january: '01',
  feb: '02',
  february: '02',
  mar: '03',
  march: '03',
  apr: '04',
  april: '04',
  may: '05',
  jun: '06',
  june: '06',
  jul: '07',
  july: '07',
  aug: '08',
  august: '08',
  sep: '09',
  sept: '09',
  september: '09',
  oct: '10',
  october: '10',
  nov: '11',
  november: '11',
  dec: '12',
  december: '12'
};

function normalizeYearNumber(rawYear: string | number): string {
  const y = parseInt(String(rawYear), 10);
  if (isNaN(y)) return '2026';
  if (y < 100) {
    // 2-digit year (e.g. 26 -> 2026, 99 -> 1999)
    return String(y < 70 ? 2000 + y : 1900 + y);
  }
  return String(y);
}

export function normDate(v: unknown): string | null {
  if (v instanceof Date && !isNaN(v.getTime())) {
    // XLSX/Google-Sheets exports frequently bake the sheet's local timezone into the
    // exported date serial: "local midnight" for a given day ends up stored as some
    // non-zero UTC time on the PREVIOUS calendar day (e.g. "2026-08-08T18:29:50.000Z"
    // actually means Aug 9 in a UTC+5:30 sheet). Using the runtime's local timezone
    // getters here would make parsing non-deterministic (same file, different answers
    // depending on which timezone the code happens to run in) so we instead use a
    // fixed UTC-hour heuristic: exact midnight UTC is trusted as-is, but any other
    // time in the second half of the UTC day is treated as a positive-offset local
    // midnight that spilled into the previous UTC day, and gets rolled forward.
    const hours = v.getUTCHours();
    const isExactMidnightUTC = hours === 0 && v.getUTCMinutes() === 0 && v.getUTCSeconds() === 0;
    const rollsForward = !isExactMidnightUTC && hours >= 12;
    const base = rollsForward
      ? new Date(Date.UTC(v.getUTCFullYear(), v.getUTCMonth(), v.getUTCDate() + 1))
      : v;
    const y = base.getUTCFullYear();
    const m = String(base.getUTCMonth() + 1).padStart(2, '0');
    const d = String(base.getUTCDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  if (typeof v === 'number' && v > 1000) {
    if (XLSX.SSF && XLSX.SSF.parse_date_code) {
      const d = XLSX.SSF.parse_date_code(v);
      if (d) {
        return `${d.y}-${String(d.m).padStart(2, '0')}-${String(d.d).padStart(2, '0')}`;
      }
    }
  }
  const s = String(v ?? '').trim();
  if (!s) return null;

  // Excel serial number stored as string (e.g. "46238")
  if (/^\d{5}(?:\.\d+)?$/.test(s)) {
    const num = parseFloat(s);
    if (XLSX.SSF && XLSX.SSF.parse_date_code) {
      const d = XLSX.SSF.parse_date_code(num);
      if (d) {
        return `${d.y}-${String(d.m).padStart(2, '0')}-${String(d.d).padStart(2, '0')}`;
      }
    }
  }

  // Strip trailing time portion if present (e.g., " 14:30:00", "T14:30:00.000Z", " 10:00 AM")
  const dateOnlyStr = s.replace(/T\d{2}:\d{2}.*$/, '').replace(/\s+\d{1,2}:\d{2}(?::\d{2})?(?:\s*[AP]M)?.*$/i, '').trim();

  // 1. Format: DD-MMM-YY or DD-MMM-YYYY (e.g., "02-Aug-26", "04-Aug-2026", "03-Oct-26", "2 Aug 26")
  let m = dateOnlyStr.match(/^(\d{1,2})[-\/\.\s]([a-zA-Z]{3,9})[-\/\.\s](\d{2,4})/);
  if (m) {
    const day = String(m[1]).padStart(2, '0');
    const monthKey = m[2].toLowerCase();
    const month = MONTH_NAME_MAP[monthKey];
    const year = normalizeYearNumber(m[3]);
    if (month) {
      return `${year}-${month}-${day}`;
    }
  }

  // 2. Format: MMM-DD-YY or MMM-DD-YYYY (e.g., "Aug-02-26", "Aug 02, 2026", "October 3 2026")
  m = dateOnlyStr.match(/^([a-zA-Z]{3,9})[-\/\.\s](\d{1,2})(?:,?)?[-\/\.\s](\d{2,4})/);
  if (m) {
    const monthKey = m[1].toLowerCase();
    const month = MONTH_NAME_MAP[monthKey];
    const day = String(m[2]).padStart(2, '0');
    const year = normalizeYearNumber(m[3]);
    if (month) {
      return `${year}-${month}-${day}`;
    }
  }

  // 3. Format: YYYY-MM-DD or YYYY/MM/DD (e.g., "2026-08-02", "2026/08/02")
  m = dateOnlyStr.match(/^(\d{4})[-\/\.](\d{1,2})[-\/\.](\d{1,2})/);
  if (m) {
    const year = m[1];
    const month = String(m[2]).padStart(2, '0');
    const day = String(m[3]).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  // 4. Format: Numeric dates with separators: A/B/YYYY or A-B-YYYY or A.B.YYYY
  m = dateOnlyStr.match(/^(\d{1,2})([-\/\.])(\d{1,2})[-\/\.](\d{2,4})/);
  if (m) {
    const n1 = parseInt(m[1], 10);
    const sep = m[2];
    const n2 = parseInt(m[3], 10);
    const year = normalizeYearNumber(m[4]);

    let month = '';
    let day = '';

    if (n1 > 12) {
      // Must be DD/MM/YYYY
      day = String(n1).padStart(2, '0');
      month = String(n2).padStart(2, '0');
    } else if (n2 > 12) {
      // Must be MM/DD/YYYY
      month = String(n1).padStart(2, '0');
      day = String(n2).padStart(2, '0');
    } else if (n2 === 8 && n1 <= 31) {
      // e.g. 03/08/2026 or 03-08-2026 -> August 3rd
      month = '08';
      day = String(n1).padStart(2, '0');
    } else if (n1 === 8 && n2 <= 31) {
      // e.g. 08/03/2026 or 08-03-2026 -> August 3rd
      month = '08';
      day = String(n2).padStart(2, '0');
    } else if (sep === '/') {
      // Slashes default to MM/DD/YYYY
      month = String(n1).padStart(2, '0');
      day = String(n2).padStart(2, '0');
    } else {
      // Hyphens default to DD-MM-YYYY
      day = String(n1).padStart(2, '0');
      month = String(n2).padStart(2, '0');
    }

    return `${year}-${month}-${day}`;
  }

  // 5. Fallback Date constructor
  if (!s.startsWith('#') && !/^[^a-zA-Z0-9]+$/.test(s)) {
    const d = new Date(s);
    if (!isNaN(d.getTime()) && s.length >= 6) {
      const y = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${y}-${month}-${day}`;
    }
  }
  return null;
}

export function formatDateDDMMYYYY(dateStr: string | null | undefined): string {
  if (!dateStr) return '—';
  const clean = String(dateStr).trim();
  const m = clean.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (m) {
    return `${m[3]}-${m[2]}-${m[1]}`;
  }
  return clean;
}

// Buckets a YYYY-MM-DD date into its containing Sunday-Saturday week, returned as the
// ISO date of that week's Sunday. Employees can legitimately log the same task on a
// different calendar day than the company's backend timesheet, but always within the
// same payroll week, so audits should compare weeks rather than exact days.
export function weekStartKey(dateStr: string): string | null {
  const m = dateStr.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return null;
  const d = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])));
  if (isNaN(d.getTime())) return null;
  d.setUTCDate(d.getUTCDate() - d.getUTCDay());
  const y = d.getUTCFullYear();
  const mo = String(d.getUTCMonth() + 1).padStart(2, '0');
  const da = String(d.getUTCDate()).padStart(2, '0');
  return `${y}-${mo}-${da}`;
}

export function parseCSV(text: string): (string | number)[][] {
  const rows: (string | number)[][] = [];
  let row: string[] = [];
  let field = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        field += c;
      }
    } else {
      if (c === '"') {
        inQuotes = true;
      } else if (c === ',') {
        row.push(field);
        field = '';
      } else if (c === '\r') {
        // Skip CR
      } else if (c === '\n') {
        row.push(field);
        rows.push(row);
        row = [];
        field = '';
      } else {
        field += c;
      }
    }
  }
  if (field.length || row.length) {
    row.push(field);
    rows.push(row);
  }
  while (rows.length && rows[rows.length - 1].every((c) => String(c).trim() === '')) {
    rows.pop();
  }
  return rows;
}

export interface SheetReadResult {
  aoa: (string | number)[][];
  sheetName: string;
  availableSheets: string[];
}

export function readSheet(
  file: File,
  preferredSheetNameSubstr: string | null = null,
  specificSheetName?: string | null
): Promise<SheetReadResult> {
  const isCsv = /\.csv$/i.test(file.name);

  // CSV files are read as explicit UTF-8 text and parsed with our own parseCSV().
  // Routing CSVs through XLSX.read()'s binary parser instead is what caused accented
  // characters (e.g. "Pêches", "Santé") to come out as mojibake ("PÃªches", "SantÃ©") -
  // XLSX's CSV auto-detection does not reliably assume UTF-8 for raw byte input.
  if (isCsv) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const text = String(e.target?.result ?? '');
          const aoa = parseCSV(text);
          if (!aoa.length) throw new Error('The CSV file is empty');
          resolve({ aoa, sheetName: file.name, availableSheets: [file.name] });
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = () => reject(new Error('File read failed'));
      reader.readAsText(file, 'utf-8');
    });
  }

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: 'array', cellDates: true });

        if (!wb.SheetNames || !wb.SheetNames.length) {
          throw new Error('The workbook contains no sheets');
        }

        let sheetName = wb.SheetNames[0];

        if (specificSheetName && wb.SheetNames.includes(specificSheetName)) {
          sheetName = specificSheetName;
        } else if (preferredSheetNameSubstr) {
          const pref = preferredSheetNameSubstr.trim().toLowerCase();

          // 1. Exact match (case-insensitive, trimmed)
          const exactHit = wb.SheetNames.find(
            (n) => n.trim().toLowerCase() === pref
          );

          if (exactHit) {
            sheetName = exactHit;
          } else {
            // 2. Substring match (e.g. "Content Tab", "Daily Content")
            const subHit = wb.SheetNames.find((n) =>
              n.toLowerCase().includes(pref)
            );
            if (subHit) {
              sheetName = subHit;
            } else {
              // 3. Check if any sheet name contains a known region keyword (e.g. "Benelux")
              const regionHit = wb.SheetNames.find((n) => mapGeographyToRegion(n) !== null);
              if (regionHit) {
                sheetName = regionHit;
              }
            }
          }
        }

        const sheet = wb.Sheets[sheetName];
        if (!sheet) {
          throw new Error(`Sheet "${sheetName}" could not be loaded`);
        }

        const aoa = XLSX.utils.sheet_to_json<(string | number)[]>(sheet, {
          header: 1,
          defval: '',
          raw: true,
        });

        resolve({
          aoa,
          sheetName,
          availableSheets: wb.SheetNames
        });
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('File read failed'));
    reader.readAsArrayBuffer(file);
  });
}

export function normalizeEmployeeRows(aoa: (string | number)[][]): RawEmployeeRow[] {
  if (!aoa.length) throw new Error('Data Pull Sheet is empty');

  // Find header row dynamically (within top 10 rows)
  let headerRowIdx = -1;
  let idx = {
    assetName: -1,
    date: -1,
    minutes: -1,
    type: -1,
    userId: -1,
    first: -1,
    last: -1,
    name: -1,
    country: -1
  };

  for (let i = 0; i < Math.min(10, aoa.length); i++) {
    const row = aoa[i].map((h) => String(h).trim().toLowerCase().replace(/[\s_-]+/g, ''));
    const rawRow = aoa[i].map((h) => String(h).trim().toLowerCase());

    const assetI = row.findIndex((h) => h.includes('assetname') || h === 'asset' || h.includes('taskname'));
    const dateI = row.findIndex((h) => h === 'date' || h.includes('date') || h === 'day' || h.includes('created') || h.includes('time'));
    const typeI = row.findIndex((h) => h === 'type' || h.includes('tasktype') || h.includes('type') || h.includes('action') || h.includes('nature'));

    if (assetI >= 0 && (dateI >= 0 || typeI >= 0)) {
      headerRowIdx = i;
      idx = {
        assetName: assetI,
        date: dateI,
        type: typeI,
        minutes: row.findIndex((h) => h.includes('minute') || h.includes('duration') || h === 'mins' || h.includes('spent') || h.includes('time')),
        userId: row.findIndex((h) => h.includes('userid') || h === 'uid' || h === 'id'),
        first: row.findIndex((h) => h.includes('userfirstname') || h.includes('firstname') || h === 'first' || h === 'fname'),
        last: row.findIndex((h) => h.includes('userlastname') || h.includes('lastname') || h === 'last' || h === 'lname'),
        name: row.findIndex((h) => h === 'name' || h.includes('username') || h.includes('employeename') || h === 'employee'),
        country: row.findIndex((h) => h === 'country' || h === 'countrycode' || h.includes('country'))
      };
      break;
    }
  }

  if (headerRowIdx < 0 || idx.assetName < 0 || idx.type < 0) {
    // Fallback to row 0 if not detected
    const header = aoa[0].map((h) => String(h).trim().toLowerCase().replace(/[\s_-]+/g, ''));
    idx = {
      assetName: header.findIndex((h) => h.includes('asset') || h.includes('task')),
      date: header.findIndex((h) => h === 'date' || h.includes('date') || h === 'day' || h.includes('time')),
      minutes: header.findIndex((h) => h.includes('minute') || h.includes('duration') || h === 'mins'),
      type: header.findIndex((h) => h === 'type' || h.includes('type')),
      userId: header.findIndex((h) => h.includes('userid') || h.includes('user')),
      first: header.findIndex((h) => h.includes('first') || h.includes('fname')),
      last: header.findIndex((h) => h.includes('last') || h.includes('lname')),
      name: header.findIndex((h) => h === 'name' || h.includes('username') || h.includes('employee')),
      country: header.findIndex((h) => h === 'country' || h === 'countrycode' || h.includes('country'))
    };
    headerRowIdx = 0;
  }

  const rows: RawEmployeeRow[] = [];
  for (let i = headerRowIdx + 1; i < aoa.length; i++) {
    const r = aoa[i];
    if (!r || !r.length) continue;
    const first = idx.first >= 0 ? String(r[idx.first] || '').trim() : '';
    const last = idx.last >= 0 ? String(r[idx.last] || '').trim() : '';
    let name = `${first} ${last}`.trim();
    if (!name && idx.name >= 0) {
      name = String(r[idx.name] || '').trim();
    }
    if (!name && idx.userId >= 0) {
      name = String(r[idx.userId] || '').trim();
    }
    if (!name) continue;

    const rawMinutes = idx.minutes >= 0 ? parseFloat(String(r[idx.minutes])) : NaN;
    const minutes = isNaN(rawMinutes) ? 0 : rawMinutes;
    const rawAsset = idx.assetName >= 0 ? String(r[idx.assetName] || '').trim() : '';
    if (!rawAsset) continue;

    const rawDateVal = idx.date >= 0 ? r[idx.date] : null;
    const parsedDate = normDate(rawDateVal);

    rows.push({
      name,
      nameKey: name.toLowerCase(),
      firstName: first,
      lastName: last,
      userId: idx.userId >= 0 ? String(r[idx.userId] || '').trim() : null,
      assetName: rawAsset,
      assetKey: normAsset(rawAsset),
      date: parsedDate,
      minutes,
      type: idx.type >= 0 ? String(r[idx.type] || '').trim() : '',
      country: idx.country >= 0 ? normalizeCountryCode(r[idx.country]) || undefined : undefined
    });
  }
  return rows;
}

export function detectRegionFromContext(
  aoa?: (string | number)[][],
  sheetName?: string,
  fileName?: string
): RegionType | null {
  // 1. Check sheet tab name (e.g. "Benelux", "Benelux Planning")
  if (sheetName) {
    const fromTab = mapGeographyToRegion(sheetName);
    if (fromTab) return fromTab;
  }

  // 2. Check file name (e.g. "Daily Planning Sheet - Benelux.xlsx")
  if (fileName) {
    const fromFile = mapGeographyToRegion(fileName);
    if (fromFile) return fromFile;
  }

  // 3. Check top 10 rows of aoa for metadata like "Region: Benelux", "Benelux Daily Planning", etc.
  if (aoa && aoa.length) {
    for (let r = 0; r < Math.min(10, aoa.length); r++) {
      const row = aoa[r];
      if (!row) continue;
      for (let c = 0; c < Math.min(10, row.length); c++) {
        const cell = String(row[c] || '').trim();
        if (!cell) continue;

        const lower = cell.toLowerCase();
        if (
          lower.includes('region') ||
          lower.includes('geography') ||
          lower.includes('market') ||
          lower.includes('territory')
        ) {
          const reg = mapGeographyToRegion(cell);
          if (reg) return reg;

          if (c + 1 < row.length) {
            const nextCell = String(row[c + 1] || '').trim();
            const nextReg = mapGeographyToRegion(nextCell);
            if (nextReg) return nextReg;
          }
        } else {
          const directReg = mapGeographyToRegion(cell);
          if (directReg) return directReg;
        }
      }
    }
  }

  return null;
}

export function normalizeEmployerRows(
  aoa: (string | number)[][],
  context?: {
    fileName?: string;
    sheetName?: string;
    defaultRegion?: string;
  }
): RawEmployerRow[] {
  if (!aoa || !aoa.length) return [];

  // Sheet-level region detection
  const detectedSheetRegion =
    detectRegionFromContext(aoa, context?.sheetName, context?.fileName) || undefined;
  const forcedRegion =
    context?.defaultRegion && context.defaultRegion !== 'auto' && context.defaultRegion !== 'mixed'
      ? (context.defaultRegion as RegionType)
      : undefined;
  let fallbackSheetRegion = forcedRegion || detectedSheetRegion;

  // Check top-level cell for "Week Identifier" or "Region" (e.g. Row 0: "Week Identifier,202638")
  let topLevelWeek = '';
  for (let i = 0; i < Math.min(6, aoa.length); i++) {
    const row = aoa[i];
    if (row && row.length >= 2) {
      const cell0 = String(row[0] || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      const cell1 = String(row[1] || '').trim();
      if ((cell0.includes('weekidentifier') || cell0 === 'week') && cell1) {
        topLevelWeek = cell1;
      }
      if ((cell0.includes('region') || cell0.includes('geography') || cell0.includes('market')) && cell1) {
        const parsed = mapGeographyToRegion(cell1);
        if (parsed) fallbackSheetRegion = parsed;
      }
    }
  }

  let headerRowIdx = -1;
  let idx = {
    week: -1,
    day: -1,
    date: -1,
    asset: -1,
    geography: -1,
    inTheNews: -1,
    production: -1,
    review: -1,
    status: -1,
    employee: -1
  };

  for (let i = 0; i < Math.min(25, aoa.length); i++) {
    const rawRow = aoa[i].map((c) => String(c || '').trim());
    const row = rawRow.map((c) => c.toLowerCase().replace(/[^a-z0-9]/g, ''));

    const weekI = row.findIndex((h) => h === 'week' || h.includes('week'));
    const dayI = row.findIndex((h) => h === 'day');
    const dateI = row.findIndex((h) => h === 'date' || h.includes('date'));
    const assetI = row.findIndex((h) =>
      h.includes('asset') ||
      h.includes('task') ||
      h === 'name' ||
      h.includes('assetname') ||
      h.includes('company') ||
      h.includes('client') ||
      h.includes('account') ||
      h.includes('entity') ||
      h.includes('title')
    );
    const geoI = row.findIndex((h) =>
      h.includes('geo') ||
      h.includes('geography') ||
      h.includes('region') ||
      h.includes('country') ||
      h.includes('market') ||
      h.includes('location') ||
      h.includes('territory') ||
      h.includes('cluster') ||
      h.includes('hub') ||
      h.includes('area') ||
      h.includes('zone') ||
      h.includes('office')
    );
    const newsI = row.findIndex((h) => h.includes('news') || h.includes('inthenews'));
    const prodI = row.findIndex((h) => h.includes('production') || h === 'prod' || h.includes('update') || h === 'full' || h === 'limited');
    const revI = row.findIndex((h) => h.includes('review') || h === 'rev' || h === 'r');
    const statusI = row.findIndex((h) => h.includes('status') || h.includes('state'));
    const empI = row.findIndex((h) =>
      h.includes('analyst') ||
      h.includes('curator') ||
      h.includes('assignee') ||
      h.includes('employee') ||
      h.includes('worker') ||
      h.includes('owner') ||
      h.includes('doneby') ||
      h.includes('person')
    );

    if (assetI >= 0 && (prodI >= 0 || revI >= 0 || dateI >= 0 || empI >= 0)) {
      headerRowIdx = i;
      idx = {
        week: weekI,
        day: dayI,
        date: dateI,
        asset: assetI,
        geography: geoI,
        inTheNews: newsI,
        production: prodI,
        review: revI,
        status: statusI,
        employee: empI
      };
      break;
    }
  }

  if (headerRowIdx < 0 || idx.asset < 0) {
    // Fallback search across all rows
    for (let i = 0; i < aoa.length; i++) {
      const row = aoa[i].map((c) => String(c || '').trim().toLowerCase().replace(/[^a-z0-9]/g, ''));
      const assetI = row.findIndex((h) => h.includes('asset') || h.includes('task') || h.includes('company') || h.includes('client') || h.includes('name'));
      if (assetI >= 0) {
        headerRowIdx = i;
        idx = {
          week: row.findIndex((h) => h === 'week' || h.includes('week')),
          day: row.findIndex((h) => h === 'day'),
          date: row.findIndex((h) => h.includes('date') || h.includes('day')),
          asset: assetI,
          geography: row.findIndex((h) =>
            h.includes('geo') ||
            h.includes('geography') ||
            h.includes('region') ||
            h.includes('country') ||
            h.includes('market') ||
            h.includes('location') ||
            h.includes('territory')
          ),
          inTheNews: row.findIndex((h) => h.includes('news')),
          production: row.findIndex((h) => h.includes('production') || h.includes('prod') || h.includes('update')),
          review: row.findIndex((h) => h.includes('review') || h.includes('rev')),
          status: row.findIndex((h) => h.includes('status') || h.includes('state')),
          employee: row.findIndex((h) =>
            h.includes('analyst') ||
            h.includes('curator') ||
            h.includes('assignee') ||
            h.includes('employee') ||
            h.includes('worker')
          )
        };
        break;
      }
    }
  }

  if (headerRowIdx < 0 || idx.asset < 0) {
    throw new Error('Could not find a Date / Asset name / Production / Review / Analyst header row in the Daily Planning Sheet');
  }

  const rows: RawEmployerRow[] = [];
  for (let i = headerRowIdx + 1; i < aoa.length; i++) {
    const r = aoa[i];
    if (!r || !r.length) continue;
    const asset = idx.asset >= 0 ? String(r[idx.asset] || '').trim() : '';
    const dateRaw = idx.date >= 0 ? r[idx.date] : '';
    const analystRaw = idx.employee >= 0 ? String(r[idx.employee] || '').trim() : '';

    // Skip empty lines or pure spacer rows where asset is empty
    if (!asset) continue;

    const parsedDate = normDate(dateRaw);
    const rowWeek = idx.week >= 0 ? String(r[idx.week] || '').trim() : '';
    const effectiveWeek = rowWeek || topLevelWeek || (parsedDate ? weekStartKey(parsedDate) || '' : '');

    const geoRaw = idx.geography >= 0 ? String(r[idx.geography] || '').trim() : '';
    const rowRegion = mapGeographyToRegion(geoRaw);
    const effectiveRegion = forcedRegion || rowRegion || fallbackSheetRegion || undefined;

    rows.push({
      assetName: asset,
      assetKey: normAsset(asset),
      date: parsedDate,
      production: idx.production >= 0 ? String(r[idx.production] || '').trim() : '',
      review: idx.review >= 0 ? String(r[idx.review] || '').trim() : '',
      status: idx.status >= 0 ? String(r[idx.status] || '').trim() : '',
      employee: analystRaw || undefined,
      week: effectiveWeek || undefined,
      day: idx.day >= 0 ? String(r[idx.day] || '').trim() : undefined,
      geography: geoRaw || undefined,
      region: effectiveRegion,
      inTheNews: idx.inTheNews >= 0 ? String(r[idx.inTheNews] || '').trim() : undefined
    });
  }
  return rows;
}

const COUNTRY_ALIASES: Record<string, string> = {
  // United States / United Kingdom
  us: 'US', usa: 'US', unitedstates: 'US', unitedstatesofamerica: 'US', america: 'US',
  gb: 'GB', uk: 'GB', gbr: 'GB', unitedkingdom: 'GB', greatbritain: 'GB', britain: 'GB',
  england: 'GB', scotland: 'GB', wales: 'GB', northernireland: 'GB',
  // France
  fr: 'FR', fra: 'FR', france: 'FR',
  // DACH
  de: 'DE', deu: 'DE', ger: 'DE', germany: 'DE', deutschland: 'DE',
  at: 'AT', aut: 'AT', austria: 'AT', oesterreich: 'AT', osterreich: 'AT',
  ch: 'CH', che: 'CH', switzerland: 'CH', schweiz: 'CH', suisse: 'CH', svizzera: 'CH',
  // Benelux
  be: 'BE', bel: 'BE', belgium: 'BE', belgie: 'BE', belgique: 'BE',
  nl: 'NL', nld: 'NL', netherlands: 'NL', thenetherlands: 'NL', holland: 'NL', nederland: 'NL',
  lu: 'LU', lux: 'LU', luxembourg: 'LU', luxemburg: 'LU',
  // Southern Europe
  es: 'ES', esp: 'ES', spain: 'ES', espana: 'ES',
  it: 'IT', ita: 'IT', italy: 'IT', italia: 'IT',
  pt: 'PT', prt: 'PT', portugal: 'PT',
  gr: 'GR', grc: 'GR', greece: 'GR', hellas: 'GR',
  cy: 'CY', cyp: 'CY', cyprus: 'CY',
  mt: 'MT', mlt: 'MT', malta: 'MT',
  // NORCEE
  pl: 'PL', pol: 'PL', poland: 'PL', polska: 'PL',
  cz: 'CZ', cze: 'CZ', czechia: 'CZ', czechrepublic: 'CZ',
  se: 'SE', swe: 'SE', sweden: 'SE', sverige: 'SE',
  no: 'NO', nor: 'NO', norway: 'NO', norge: 'NO',
  dk: 'DK', dnk: 'DK', denmark: 'DK', danmark: 'DK',
  fi: 'FI', fin: 'FI', finland: 'FI', suomi: 'FI',
  ee: 'EE', est: 'EE', estonia: 'EE',
  lv: 'LV', lva: 'LV', latvia: 'LV',
  lt: 'LT', ltu: 'LT', lithuania: 'LT',
  sk: 'SK', svk: 'SK', slovakia: 'SK',
  hu: 'HU', hun: 'HU', hungary: 'HU',
  ro: 'RO', rou: 'RO', romania: 'RO',
  bg: 'BG', bgr: 'BG', bulgaria: 'BG'
};

/**
 * Normalises a country value (ISO-2 code, ISO-3 code, English/local name, or
 * common alias) to an upper-case ISO 3166-1 alpha-2 code, e.g. "Germany" -> "DE",
 * "GBR" -> "GB", "uk" -> "GB". Unrecognised values are returned trimmed and
 * upper-cased so callers can still compare them against configured codes.
 * Returns '' for empty input.
 */
export function normalizeCountryCode(val?: unknown): string {
  if (val === null || val === undefined) return '';
  const raw = String(val).trim();
  if (!raw) return '';
  const key = raw.toLowerCase().replace(/[^a-z]/g, '');
  return COUNTRY_ALIASES[key] || raw.toUpperCase();
}

export function mapGeographyToRegion(geo?: string | null): RegionType | null {
  if (!geo) return null;
  const raw = String(geo).trim().toLowerCase();
  const s = raw.replace(/[^a-z0-9]/g, '');
  if (!s) return null;

  // Benelux (Netherlands, Belgium, Luxembourg)
  if (
    s.includes('benelux') ||
    s === 'bnl' ||
    s === 'nl' ||
    s.includes('netherland') ||
    s.includes('holland') ||
    s === 'be' ||
    s.includes('belgi') || // belgium, belgique, belgie, belgian
    s === 'lu' ||
    s.includes('luxemb') || // luxembourg, luxemburg
    s === 'benl' ||
    s === 'nlbe' ||
    s.includes('amsterdam') ||
    s.includes('rotterdam') ||
    s.includes('hague') ||
    s.includes('brussel') ||
    s.includes('antwerp') ||
    s.includes('ghent') ||
    s.includes('dutch') ||
    s.includes('flemish')
  ) {
    return 'Benelux';
  }

  // The UK/US
  if (
    s === 'uk' ||
    s === 'us' ||
    s.includes('uknice') ||
    s.includes('ukandnice') ||
    s === 'ukus' ||
    s === 'theukus' ||
    s.includes('unitedkingdom') ||
    s.includes('greatbritain') ||
    s.includes('britain') ||
    s.includes('england') ||
    s.includes('scotland') ||
    s.includes('wales') ||
    s.includes('london') ||
    s.includes('unitedstates') ||
    s === 'usa' ||
    s.includes('america') ||
    s === 'gbr'
  ) {
    return 'The UK/US';
  }

  // Southern Europe (Spain, Italy, Portugal, Greece)
  if (
    s === 'se' ||
    s.includes('southerneurope') ||
    s === 'es' ||
    s.includes('spain') ||
    s.includes('espana') ||
    s.includes('spanish') ||
    s === 'it' ||
    s.includes('ital') ||
    s === 'pt' ||
    s.includes('portug') ||
    s === 'gr' ||
    s.includes('gree') ||
    s.includes('iberia') ||
    s.includes('madrid') ||
    s.includes('barcelona') ||
    s.includes('milan') ||
    s.includes('rome') ||
    s.includes('lisbon') ||
    s.includes('athens')
  ) {
    return 'Southern Europe';
  }

  // France
  if (
    s.includes('franc') ||
    s.includes('french') ||
    s === 'fr' ||
    s.includes('paris')
  ) {
    return 'France';
  }

  // DACH (Germany, Austria, Switzerland)
  if (
    s.includes('dach') ||
    s === 'de' ||
    s.includes('german') ||
    s.includes('deutsch') ||
    s === 'at' ||
    s.includes('austria') ||
    s.includes('oesterreich') ||
    s === 'ch' ||
    s.includes('switz') ||
    s.includes('schweiz') ||
    s.includes('berlin') ||
    s.includes('munich') ||
    s.includes('frankfurt') ||
    s.includes('vienna') ||
    s.includes('zurich')
  ) {
    return 'DACH';
  }

  // NORCEE (Nordics & Central Eastern Europe)
  if (
    s.includes('norcee') ||
    s.includes('nordic') ||
    s.includes('cee') ||
    s.includes('poland') ||
    s.includes('polska') ||
    s.includes('polish') ||
    s.includes('czech') ||
    s.includes('denmark') ||
    s.includes('danmark') ||
    s.includes('danish') ||
    s.includes('norway') ||
    s.includes('norge') ||
    s.includes('norwegian') ||
    s.includes('finland') ||
    s.includes('suomi') ||
    s.includes('finnish') ||
    s.includes('sweden') ||
    s.includes('sverige') ||
    s.includes('swedish') ||
    s === 'pl' ||
    s === 'cz' ||
    s === 'dk' ||
    s === 'no' ||
    s === 'fi' ||
    (s === 'se' && (raw.includes('sweden') || raw.includes('sverige'))) ||
    s.includes('warsaw') ||
    s.includes('prague') ||
    s.includes('copenhagen') ||
    s.includes('oslo') ||
    s.includes('stockholm') ||
    s.includes('helsinki')
  ) {
    return 'NORCEE';
  }

  return null;
}

export function matchAnalyst(nameA?: string | null, nameB?: string | null): boolean {
  if (!nameA || !nameB) return false;
  const a = String(nameA).trim().toLowerCase().replace(/\s+/g, ' ');
  const b = String(nameB).trim().toLowerCase().replace(/\s+/g, ' ');
  if (a === b) return true;

  // Handle "Last, First" format
  const normA = a.includes(',') ? a.split(',').reverse().map((s) => s.trim()).join(' ') : a;
  const normB = b.includes(',') ? b.split(',').reverse().map((s) => s.trim()).join(' ') : b;
  if (normA === normB) return true;

  // Word-based match (first & last)
  const wordsA = normA.split(' ').filter(Boolean);
  const wordsB = normB.split(' ').filter(Boolean);
  if (wordsA.length >= 2 && wordsB.length >= 2) {
    const firstA = wordsA[0];
    const lastA = wordsA[wordsA.length - 1];
    const firstB = wordsB[0];
    const lastB = wordsB[wordsB.length - 1];
    if (firstA === firstB && lastA === lastB) return true;
  }
  return false;
}

export function getAvailableWeeks(
  employerRows: RawEmployerRow[] | null,
  employeeRows: RawEmployeeRow[] | null
): WeekInfo[] {
  const weekMap = new Map<string, { weekId: string; dates: string[]; analysts: Set<string>; tasks: number }>();

  if (employerRows && employerRows.length) {
    employerRows.forEach((r) => {
      const weekId = r.week || (r.date ? weekStartKey(r.date) : null);
      if (!weekId) return;

      if (!weekMap.has(weekId)) {
        weekMap.set(weekId, {
          weekId,
          dates: [],
          analysts: new Set(),
          tasks: 0
        });
      }
      const entry = weekMap.get(weekId)!;
      if (r.date) entry.dates.push(r.date);
      if (r.employee && r.employee.trim()) entry.analysts.add(r.employee.trim());
      if (r.assetName) entry.tasks++;
    });
  }

  // If no employer weeks were derived, fallback to dates in employeeRows
  if (weekMap.size === 0 && employeeRows && employeeRows.length) {
    employeeRows.forEach((r) => {
      if (!r.date) return;
      const weekId = weekStartKey(r.date);
      if (!weekId) return;
      if (!weekMap.has(weekId)) {
        weekMap.set(weekId, {
          weekId,
          dates: [],
          analysts: new Set(),
          tasks: 0
        });
      }
      const entry = weekMap.get(weekId)!;
      entry.dates.push(r.date);
      if (r.name) entry.analysts.add(r.name);
      entry.tasks++;
    });
  }

  const result: WeekInfo[] = [];
  weekMap.forEach((val, weekId) => {
    val.dates.sort();
    const startDate = val.dates.length ? val.dates[0] : '';
    const endDate = val.dates.length ? val.dates[val.dates.length - 1] : '';

    let label = '';
    if (/^\d{6}$/.test(weekId)) {
      const yr = weekId.slice(0, 4);
      const wk = weekId.slice(4);
      label = `Week ${weekId} (Wk ${parseInt(wk, 10)}, ${yr})`;
    } else {
      label = `Week of ${formatDateDDMMYYYY(startDate)}`;
    }

    if (startDate && endDate) {
      label += ` • ${formatDateDDMMYYYY(startDate)} to ${formatDateDDMMYYYY(endDate)}`;
    }

    result.push({
      weekId,
      label,
      startDate,
      endDate,
      analystCount: val.analysts.size,
      taskCount: val.tasks
    });
  });

  result.sort((a, b) => b.weekId.localeCompare(a.weekId));
  return result;
}

export function extractSheetInfo(url: string): { id: string; gid: string } | null {
  const idMatch = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if (!idMatch) return null;
  const id = idMatch[1];
  let gid = '0';
  const gidMatch = url.match(/[#?&]gid=(\d+)/);
  if (gidMatch) gid = gidMatch[1];
  return { id, gid };
}

export function lastWeekWindow(today: Date = new Date()): { start: string; end: string } {
  // Sunday - Saturday: Most recent completed calendar week (Sunday through Saturday)
  const currentDay = today.getDay(); // 0 = Sunday, 1 = Monday, ... 6 = Saturday
  const endLocal = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  // Last week Saturday is today - currentDay - 1
  endLocal.setDate(endLocal.getDate() - currentDay - 1);
  const startLocal = new Date(endLocal);
  // Last week Sunday is 6 days before Saturday
  startLocal.setDate(startLocal.getDate() - 6);
  const toIso = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  return { start: toIso(startLocal), end: toIso(endLocal) };
}

export function getAvailableRegions(
  employerRows: RawEmployerRow[] | null,
  selectedWeekId?: string
): RegionInfo[] {
  const targetRegions: RegionType[] = [
    'The UK/US',
    'France',
    'DACH',
    'Benelux',
    'Southern Europe',
    'NORCEE'
  ];

  const regionData = new Map<RegionType, { analysts: Set<string>; tasks: number }>();
  targetRegions.forEach((r) => regionData.set(r, { analysts: new Set(), tasks: 0 }));

  if (employerRows && employerRows.length) {
    employerRows.forEach((row) => {
      // Filter by week if specified
      if (selectedWeekId && selectedWeekId !== 'all') {
        if (row.week && row.week !== selectedWeekId) return;
      }

      const reg = row.region || mapGeographyToRegion(row.geography);
      if (reg && regionData.has(reg as RegionType)) {
        const item = regionData.get(reg as RegionType)!;
        item.tasks++;
        if (row.employee && row.employee.trim()) {
          item.analysts.add(row.employee.trim());
        }
      }
    });
  }

  return targetRegions.map((name) => {
    const data = regionData.get(name)!;
    return {
      name,
      countryCodes: DEFAULT_REGION_COUNTRY_CODES[name] || [],
      analystCount: data.analysts.size,
      taskCount: data.tasks
    };
  });
}

